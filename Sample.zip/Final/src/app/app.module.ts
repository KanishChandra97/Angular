import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppComponent } from './app.component';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DisplayComponent } from './Display/Display.component'
import { HttpClientModule } from '@angular/common/http';
import { EmployeeService } from './../app/Employee.service';
import { EmpFilter } from './../app/Pipe/PipeFilter'
@NgModule({
  declarations: [
    AppComponent,
    DisplayComponent,
    EmpFilter
  ],
  imports: [
    BrowserModule,
    HttpClientModule,
    FormsModule,
    ReactiveFormsModule
  ],
  providers: [EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
