import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import { IEmployee } from './../app/Employee';
import { Observable } from 'rxjs';
import { of } from 'rxjs';
@Injectable()
export class EmployeeService
{
    private _url:string = "/assets/Data/Employee.json";
    constructor(private http:HttpClient)
    {
    };
    getEmployees():Observable<IEmployee[]>
    {
    return this.http.get<IEmployee[]>(this._url);
    }
}
