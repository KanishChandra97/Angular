import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
    name:'filter'
})
export class EmpFilter implements PipeTransform{
    transform(List: any[], EmpID:number):any[] {
        if(!List){
            return [];
        }
        if(!EmpID){
            return ["No Employee Found"];
        }
        return List.filter(dt=>{ return dt.Id==EmpID;})
    }
}