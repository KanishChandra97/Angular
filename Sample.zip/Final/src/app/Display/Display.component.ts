import { OnInit, Component } from '@angular/core';
import { EmployeeService } from './../Employee.service';
import { IEmployee } from './../Employee';
import {FormBuilder,FormGroup} from '@angular/forms';

@Component({
    selector:"Display",
    templateUrl:'./Display.component.html'
})
export class DisplayComponent implements OnInit
{
    List:IEmployee[];
    submitted:boolean = false;
    ngOnInit(): void
    {
        this.getAll();
    }
    constructor(private empservice:EmployeeService,private formBuilder:FormBuilder)
    {
    }
    getAll()
    {
        this.empservice.getEmployees().subscribe(data=>{this.List=data;});
    }
    onSubmit()
    {
        this.submitted=true;
        this.empservice.getEmployees().subscribe(data=>{this.List=data;})   
    }
    txtchanged()
    {
        this.submitted=false;
    }
}